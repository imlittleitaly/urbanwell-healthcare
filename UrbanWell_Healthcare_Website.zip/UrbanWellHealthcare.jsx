
import React from "react";

export default function UrbanWellHealthcare() {
  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <header className="text-center">
        <h1 className="text-4xl font-bold">UrbanWell Family Health Center</h1>
        <p className="mt-2 text-lg">Empowering communities through equitable, compassionate care.</p>
      </header>

      <section>
        <h2 className="text-2xl font-semibold">Our Mission & Vision</h2>
        <p className="mt-2">Mission: To deliver compassionate, equitable, and quality health care that empowers individuals and strengthens communities.</p>
        <p className="mt-1">Vision: To create a healthier future where every person regardless of income, language, or background has access to exceptional, patient-centered care.</p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold">Our Program: Healthy Start – Women’s Wellness Program</h2>
        <p className="mt-2">Healthy Start is a comprehensive women’s health initiative offering annual wellness exams, pap smears, breast cancer screenings, prenatal care, birth control counseling, and nutrition coaching. Our goal is to reduce health disparities by providing flexible scheduling, bilingual support, and sliding-scale fees. Educational workshops and telehealth options are available.</p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold">Marketing Strategies</h2>
        <ul className="list-disc pl-6 mt-2 space-y-1">
          <li>Targeted social media campaigns (measured by engagement rates)</li>
          <li>Community outreach and health fairs (measured by attendance & sign-ups)</li>
          <li>Email newsletters (measured by open & click-through rates)</li>
          <li>Referral incentives for existing patients (measured by new patient referrals)</li>
          <li>Online reviews and reputation management (measured by star ratings & feedback)</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold">Measuring Strategy Success</h2>
        <ul className="list-disc pl-6 mt-2 space-y-1">
          <li>Use Google Analytics for website traffic & behavior insights</li>
          <li>Utilize CRM tools to monitor referral and patient engagement trends</li>
          <li>Survey tools for gathering direct feedback post-service</li>
          <li>Email marketing platforms to track interaction data</li>
          <li>Social media dashboards (Meta, X, Instagram Insights) to gauge awareness</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold">Target Market & Segmentation</h2>
        <p className="mt-2">Our program serves women ages 18–45, primarily from low- to moderate-income African American and Hispanic backgrounds in urban Atlanta. We use geographic, demographic, and behavioral segmentation to tailor our services, such as providing care in Spanish and aligning appointment hours with public transit schedules.</p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold">Marketing Challenges & Recommendations</h2>
        <p className="mt-2">Challenges include limited digital access, distrust in healthcare systems, and language barriers. We recommend investing in bilingual marketing, partnering with trusted community leaders, using SMS appointment reminders, and offering culturally relevant services and messaging to build trust and retention.</p>
      </section>
    </div>
  );
}
    